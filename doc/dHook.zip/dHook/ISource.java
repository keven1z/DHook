package dHook;

/**
 * @author keven1z
 * @date 2022/07/29
 * 标志Source接口
 */
public interface ISource{
}
