package dHook;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;

/**
 * @author keven1z
 * @date 2022/07/29
 */
public class SourceDHookExtenderCallbacks extends DefaultDHookExtenderCallbacks{
    private Set<Source> sources = new HashSet<>();

    @Override
    public Set<Source> getSource() {
        if(sources.isEmpty()){
            try {
                Class<?> agent = Class.forName("com.keven1z.Agent");
                Field field = agent.getField("context");
                Object context = field.get(agent);
                Class<?> contextClass = context.getClass();
                Method method = contextClass.getDeclaredMethod("getSources");

                Set<Source> sources = (Set<Source>)method.invoke(context);
                return sources;
            } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                return sources;
            }
        }
        return sources;
    }
}
