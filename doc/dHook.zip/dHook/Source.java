package dHook;

import java.util.List;

/**
 * @author keven1z
 * @date 2022/07/29
 */
public class Source {
    /**
     * source自身对象
     */
    private Object sourceThis;
    /**
     * 源的入参
     */
    private List<Object> parameter;
    /**
     * 源的返回值
     */
    private Object returnValue;

    public Object getSourceThis() {
        return sourceThis;
    }

    public void setSourceThis(Object sourceThis) {
        this.sourceThis = sourceThis;
    }

    public List<Object> getParameter() {
        return parameter;
    }

    public void setParameter(List<Object> parameter) {
        this.parameter = parameter;
    }

    public Object getReturnValue() {
        return returnValue;
    }

    public void setReturnValue(Object returnValue) {
        this.returnValue = returnValue;
    }
}
